# Checklist

- [ ] `translations.py` 翻译字典模块已创建并包含所有必要翻译
- [ ] `__init__.py` 中所有面向用户的字符串已翻译为中文
- [ ] `gui/__init__.py` 中所有面板标签已翻译为中文
- [ ] `gui/__init__.py` 中所有属性名称已翻译为中文
- [ ] `gui/__init__.py` 中所有下拉框选项已翻译为中文
- [ ] `gui/__init__.py` 中所有操作符标签已翻译为中文
- [ ] `ape/__init__.py` 中所有操作符标签已翻译为中文
- [ ] `ape/__init__.py` 中所有属性已翻译为中文
- [ ] `realistic/__init__.py` 中所有UI字符串已翻译为中文
- [ ] `util/blender_extra/material.py` 中所有UI字符串已翻译为中文
- [ ] `util/blender_extra/baking.py` 中所有UI字符串已翻译为中文
- [ ] 所有 `bl_idname` 保持一致，未被修改
- [ ] 所有 `bl_description` 已翻译
- [ ] 专有名词处理一致（保留英文或采用通用译名）
- [ ] 代码语法正确，无拼写错误
