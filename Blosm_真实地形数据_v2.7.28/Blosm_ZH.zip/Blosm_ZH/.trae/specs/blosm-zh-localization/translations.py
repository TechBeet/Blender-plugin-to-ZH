# Blosm插件汉化 - 翻译字典
# 所有UI字符串的中文翻译集合
# bl_idname保持不变，仅翻译bl_label、bl_description、name、description等UI显示字符串

# ========== 主插件入口 (__init__.py) ==========

# bl_info相关
BLOSM_NAME = "Blosm"
BLOSM_DESCRIPTION = "OpenStreetMap、Google 3D 城市、地形、卫星图像、网格地图的快速导入"

# 偏好设置相关
PREFERENCES_SCREEN_TYPE = "屏幕类型"
PREFERENCES_APE = "资产包编辑器"
PREFERENCES_DATA_DIR = "数据目录"
PREFERENCES_ASSETS_DIR = "资产目录"
PREFERENCES_MAPBOX_ACCESS_TOKEN = "Mapbox 访问令牌"
PREFERENCES_ARCGIS_ACCESS_TOKEN = "ArcGIS 访问令牌"
PREFERENCES_GOOGLE_MAPS_API_KEY = "Google 3D Tiles 密钥"
PREFERENCES_OSM_SERVER = "OSM 数据服务器"
PREFERENCES_ENABLE_EXPERIMENTAL_FEATURES = "启用导出（实验性功能）"

# 操作符相关
OT_GET_ARCGIS_TOKEN_LABEL = "获取 ArcGIS API 密钥"
OT_GET_MAPBOX_TOKEN_LABEL = "获取 Mapbox 访问令牌"
OT_GET_GOOGLE_MAPS_API_KEY_LABEL = "获取 Google 3D Tiles 密钥"
OT_GET_PRO_VERSION_LABEL = "获取 Blosm 专业版"

# ========== GUI面板 (gui/__init__.py) ==========

# 面板标签
PANEL_EXTENT = "Blosm"
PANEL_SETTINGS = "设置"
PANEL_TOOLS = "工具"
PANEL_PROJECTION = "投影"
PANEL_COPYRIGHT = "版权"
PANEL_REALISTIC_MODE = "真实模式"
PANEL_APE = "Blosm 资产包编辑器"

# 数据类型
DATA_TYPE_OSM = "OpenStreetMap"
DATA_TYPE_TERRAIN = "地形"
DATA_TYPE_OVERLAY = "图像叠加"
DATA_TYPE_3D_TILES = "3D Tiles"
DATA_TYPE_GPX = "GPX 轨迹"
DATA_TYPE_GEOJSON = "GeoJSON"

# 导入选项
IMPORT_FROM = "导入来源"
IMPORT_FROM_SERVER = "远程服务器"
IMPORT_FROM_FILE = "本地磁盘文件"
OPENSTREETMAP_FILE = "OpenStreetMap 文件"

# 模式
MODE_3D_REALISTIC = "3D 写实"
MODE_3D_SIMPLE = "3D 简单"
MODE_2D = "2D"

# 建筑相关
IMPORT_BUILDINGS = "导入建筑"
IMPORT_WATER = "导入水体"
IMPORT_FORESTS = "导入森林"
IMPORT_VEGETATION = "导入其他植被"
IMPORT_HIGHWAYS = "导入道路和路径"
IMPORT_RAILWAYS = "导入铁路"
DEFAULT_ROOF_SHAPE = "默认屋顶形状"
FLAT = "平顶"
GABLED = "双坡屋顶"

# 级别相关
DEFAULT_LEVELS = "默认楼层数"
LEVEL_HEIGHT = "层高"
STRAIGHT_ANGLE_THRESHOLD = "直角阈值"
LOAD_MISSING_MEMBERS = "加载缺失的关联成员"

# 细分曲线相关
SUBDIVIDE_CURVES = "细分曲线和平面图层"
SUBDIVISION_SIZE = "细分大小"

# 地形相关
TERRAIN_RESOLUTION = "分辨率"
TERRAIN_MESH_PRIMITIVE_TYPE = "地形网格图元类型"
TERRAIN_REDUCTION_RATIO = "顶点减少比率"
VERTEX_COUNT = "顶点数量"

# 覆盖层相关
OVERLAY_TYPE = "覆盖层类型"
OVERLAY_ARCGIS_SATELLITE = "ArcGIS 卫星影像"
OVERLAY_MAPBOX_SATELLITE = "Mapbox 卫星影像"
OVERLAY_OSM_MAPNIK = "OSM Mapnik"
OVERLAY_MAPBOX_STREETS = "Mapbox 街道"
OVERLAY_CUSTOM = "自定义 URL"
SET_DEFAULT_MATERIAL = "设置默认材质"
SAVE_OVERLAY_TO_FILE = "保存覆盖层到文件"
MAX_NUM_TILES = "最大覆盖层瓦片数"
OVERLAY_URL = "覆盖层 URL"

# 3D Tiles相关
SOURCE_OF_3D_TILES = "3D Tiles 来源"
GOOGLE_3D_TILES = "Google"
CUSTOM_3D_TILES = "自定义"
LEVEL_OF_DETAILS = "细节级别"
LOD1 = "整个城市"
LOD2 = "城区"
LOD3 = "建筑群"
LOD4 = "独立建筑"
LOD5 = "带细节的建筑"
LOD6 = "带更多细节的建筑"
GEOMETRIC_ERROR = "几何误差"
JOIN_3D_TILES_OBJECTS = "合并 3D Tiles 对象"
CACHE_JSON_FILES = "缓存 JSON 文件"
CACHE_3D_FILES = "缓存 3D 文件"

# GPX相关
GPX_FILE = "GPX 文件"
GPX_PROJECT_ON_TERRAIN = "将 GPX 轨迹投影到地形"
GPX_IMPORT_TYPE = "导入类型"
CURVE = "曲线"
MESH = "网格"

# 真实模式相关
TREES_PER_HECTARE = "每公顷树木数"
MAKE_REALISTIC_LAYER = "“真实化”图层"
LIT_WINDOWS = "亮灯窗户百分比"
ASSET_PACKAGE = "资产包"

# 材质相关
MATERIAL_TYPE = "材质类型"
FO = "带窗户叠加的立面"
FS = "无缝立面"
MS = "无缝覆层"

# 几何节点相关
GEOMETRY_NODES = "几何节点"
GN2D_INFO = "关于将几何节点应用于导入的建筑轮廓的信息"
GN_BLEND_FILE_2D = "包含几何节点的文件"
GN_SETUP_2D = "几何节点设置"

# 烘焙相关
BAKE_IMAGE_SIZE = "图像尺寸"
BAKE_MARGIN_PX = "烘焙边距（像素）"
BAKE_UV_MARGIN = "UV 边距"
BAKE_CAGE_EXTRUSION = "烘焙笼挤出"
BAKE_REPLACE_ACTIVE = "替换活动项"

# ========== APE模块 (ape/__init__.py) ==========

# 操作符标签
OT_APE_LOAD_AP_LIST = "加载资产包列表"
OT_APE_EDIT_AP = "编辑资产包"
OT_APE_COPY_AP = "复制资产包"
OT_APE_INSTALL_AP = "安装"
OT_APE_UPDATE_AP = "更新资产包"
OT_APE_CANCEL = "取消"
OT_APE_APPLY_AP_NAME = "应用"
OT_APE_REMOVE_AP = "移除资产包"
OT_APE_SAVE_AP = "保存"
OT_APE_SELECT_BUILDING = "选择建筑条目"
OT_APE_ADD_BUILDING = "新建"
OT_APE_DELETE_BUILDING = "删除建筑资产集合"
OT_APE_ADD_BLDG_ASSET = "添加"
OT_APE_DELETE_BLDG_ASSET = "删除"
OT_APE_SET_ASSET_PATH = "设置路径…"

# APE属性
ASSET_PACKAGE = "资产包"
STATE = "状态"
AP_DIR_NAME = "文件夹"
AP_NAME = "名称"
AP_DESCRIPTION = "描述"
SHOW_ADVANCED_OPTIONS = "显示高级选项"
BUILDING_ASSET_COLLECTION = "建筑资产集合"
BUILDING_ASSET_ENTRY = "资产条目"
BUILDING_USE = "建筑用途"
ASSET_CATEGORY = "资产类别"
FEATURE_WIDTH_M = "要素宽度（米）"
FEATURE_LPX = "要素左坐标（像素）"
FEATURE_RPX = "要素右坐标（像素）"
USE_CLADDING_TEXTURE = "具有透明部分以使用覆层纹理"
NUM_TILES_U = "水平方向瓦片数"
NUM_TILES_V = "垂直方向瓦片数"
CLADDING_MATERIAL = "材质"
TEXTURE_WIDTH_M = "纹理宽度（米）"
BUILDING_PART = "建筑部件"

# 建筑用途
BUILDING_USE_APARTMENTS = "公寓"
BUILDING_USE_OFFICE = "办公楼"
BUILDING_USE_ANY = "任意建筑类型"

# 资产类别
ASSET_PART = "建筑部件"
ASSET_CLADDING = "覆层"

# ========== 真实模式模块 (realistic/__init__.py) ==========

MAKE_REALISTIC = "真实化"
MAKE_POLYGON = "生成多边形"
FLATTEN_SELECTED = "压平所选对象"

# 真实模式属性
TREE_DENSITY = "每公顷树木数"
WATER_LAYER = "水体"
FOREST_LAYER = "森林"
MEADOW_LAYER = "草地"
LIT_WINDOWS_PERCENTAGE = "亮灯窗户百分比"

# ========== 材质工具 (util/blender_extra/material.py) ==========

DOWNLOAD_TEXTURES = "下载纹理"
CREATE_MATERIALS = "创建材质…"
DELETE_MATERIALS = "删除材质…"
MATERIAL_UTILITIES = "材质工具"

# ========== 烘焙工具 (util/blender_extra/baking.py) ==========

BAKE_TO_SINGLE_DIFFUSE = "烘焙为单一漫射贴图"