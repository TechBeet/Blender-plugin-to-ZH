# Blosm插件汉化 Spec

## Why
Blosm Blender插件的UI界面使用英文，中国用户使用时存在语言障碍。需要将所有面向用户的字符串（面板标签、按钮文字、下拉选项、悬浮提示等）翻译为简体中文，提升用户体验。

## What Changes
- 将 `__init__.py` 中的偏好设置和操作符标签翻译为中文
- 将 `gui/__init__.py` 中的所有UI字符串翻译为中文
- 将 `ape/__init__.py` 中的资产包编辑器UI字符串翻译为中文
- 将 `realistic/__init__.py` 中的真实模式UI字符串翻译为中文
- 将 `util/blender_extra/material.py` 和 `baking.py` 中的工具UI字符串翻译为中文
- 保持 `bl_idname` 不变（内部标识符不能修改）
- 所有英文专有名词（如 "OpenStreetMap", "3D Tiles", "Geometry Nodes" 等）保留原文或采用通用译名

## Impact
- Affected files: `__init__.py`, `gui/__init__.py`, `ape/__init__.py`, `realistic/__init__.py`, `util/blender_extra/material.py`, `util/blender_extra/baking.py`
- No functional changes, only UI string translations
- All existing functionality preserved

## Translation Strategy
1. 创建一个集中化的翻译字典文件 `translations.py`，方便后续维护
2. 使用 `translations.py` 中的函数替换各文件中的硬编码字符串
3. 对于简单的单行翻译，可以直接替换字符串值
4. 保持原有的描述性文本（description）也一并翻译

## ADDED Requirements
### Requirement: 创建翻译字典模块
系统 SHALL 提供一个集中的翻译字典模块，包含所有UI字符串的中文翻译。

#### Scenario: 添加翻译条目
- **WHEN** 开发者需要添加新翻译
- **THEN** 编辑 `translations.py` 文件即可

### Requirement: 更新主插件入口文件
系统 SHALL 在 `__init__.py` 中将所有面向用户的字符串替换为中文。

#### Scenario: 偏好设置界面显示中文
- **WHEN** 用户在Blender中打开插件偏好设置
- **THEN** 看到所有标签、按钮、说明文字均为中文

### Requirement: 更新GUI面板
系统 SHALL 在 `gui/__init__.py` 中将所有面板标题、属性名称、操作符标签翻译为中文。

#### Scenario: 右侧面板显示中文
- **WHEN** 用户打开3D视图右侧的Blosm面板
- **THEN** 看到所有面板标题（如"Extent"→"范围"）、属性名（如"Import buildings"→"导入建筑"）和操作符（如"import"→"导入"）均为中文

### Requirement: 更新资产包编辑器
系统 SHALL 在 `ape/__init__.py` 中将所有UI字符串翻译为中文。

### Requirement: 更新真实模式和工具
系统 SHALL 在 `realistic/__init__.py`、`material.py`、`baking.py` 中将所有UI字符串翻译为中文
