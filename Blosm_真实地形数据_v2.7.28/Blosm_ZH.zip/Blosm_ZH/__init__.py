"""
This file is a part of Blosm addon for Blender.
Copyright (C) 2014-2023 Vladimir Elistratov
prokitektura+support@gmail.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

bl_info = {
    "name": "Blosm（简体中文）",
    "author": "Vladimir Elistratov <prokitektura+support@gmail.com>",
    "version": (2, 7, 28),
    "blender": (4, 5, 0),
    "location": "右侧面板 > \"Blosm\" 选项卡",
    "description": "快速导入 OpenStreetMap、Google 3D 城市、地形、卫星图像、网络地图",
    "warning": "",
    "wiki_url": "https://github.com/vvoovv/blosm/wiki/Premium-Version",
    "tracker_url": "https://github.com/vvoovv/blosm/issues",
    "support": "COMMUNITY",
    "category": "Import-Export",
    "blosmAssets": "2021.05.07"
}

import os, sys, textwrap

# force cleanup of sys.modules to avoid conflicts with the other addons for Blender
for m in [
        "action", "ape", "app", "building", "building2", "defs", "gpx", "grammar", "gui",
        "item", "item_renderer", "lib", "manager", "material", "mpl", "overlay", "parse",
        "pml", "realistic", "renderer", "script", "setup", "style", "terrain",
        "threed_tiles", "util", "way"
    ]:
    sys.modules.pop(m, 0)

def _checkPath():
    path = os.path.dirname(os.path.realpath(__file__))
    if path in sys.path:
        sys.path.remove(path)
    # make <path> the first one to search for a module
    sys.path.insert(0, path)
    sys.path.insert(1, os.path.join(path, "pml"))
    sys.path.insert(2, os.path.join(path, "threed_tiles"))
_checkPath()


import bpy, bmesh, blf

from .app import blender as blenderApp
# Important: <blenderApp.app> attributes must be set before importing gui, since <app.isPro> is used there
# set the minimum version for BLOSM assets
blenderApp.app.setMinAssetsVersion(bl_info["blosmAssets"])
# set addon version
blenderApp.app.version = bl_info["version"]
blenderApp.app.isPro = os.path.isdir(os.path.join(os.path.dirname(os.path.realpath(__file__)), "realistic"))

from .renderer import Renderer
from .parse.osm import Osm
from . import gui, ape
from .defs import Keys


class BlosmPreferences(bpy.types.AddonPreferences, ape.AssetPackageEditor):
    bl_idname = __name__

    screenType: bpy.props.EnumProperty(
        name="插件设置界面类型",
        items=(
            ("preferences", "偏好设置", "偏好设置"),
            ("ape", "资产包编辑器", "资产包编辑器")
        ),
        description="Asset Package Editor 的设置",
        default="preferences"
    )

    dataDir: bpy.props.StringProperty(
        name="",
        subtype='DIR_PATH',
        description="存储下载的 OpenStreetMap 和地形文件的目录"
    )

    assetsDir: bpy.props.StringProperty(
        name="",
        subtype='DIR_PATH',
        description="包含资产的目录(building_materials.blend, vegetation.blend)。" +
            "也可以在插件GUI中设置"
    )

    mapboxAccessToken: bpy.props.StringProperty(
        name="Mapbox访问令牌",
        description="用于访问 Mapbox 公司卫星图像的令牌字符串"
    )

    arcgisAccessToken: bpy.props.StringProperty(
        name="ArcGIS访问令牌",
        description="用于访问 ArcGIS 位置服务卫星图像的令牌(API Key)"
    )

    googleMapsApiKey: bpy.props.StringProperty(
        name="Google 3D Tiles密钥",
        description="用于访问 Google 3D Tiles的API Key"
    )

    osmServer: bpy.props.EnumProperty(
    name = "OSM 数据服务器",
    items = (
        ("overpass-api.de", "overpass-api.de：2 台服务器，每台 16 核、128 GB RAM", "overpass-api.de：2 台服务器，每台 8 核和 128 GB RAM"),
        ("private.coffee", "Private.coffee：4 台服务器，每台 20 核、256 GB RAM", "Private.coffee：4 台服务器，每台 20 核和 256 GB RAM"),
        ("vk maps", "VK Maps：2 台服务器，每台 56 核、384 GB RAM", "VK Maps：2 台服务器，每台 56 核和 384 GB RAM")
    ),
        description="默认服务器不可用时使用的备用OSM数据服务器",
        default="overpass-api.de"
    )

    enableExperimentalFeatures: bpy.props.BoolProperty(
        name="启用导出功能(实验性)",
        description="启用导出到主流3D格式的功能。实验性功能！请谨慎使用！",
        default=False
    )
    
    def draw(self, context):
        layout = self.layout
        
        if blenderApp.app.isPro:
            layout.box().label(text="感谢购买专业版!")
            if self.enableExperimentalFeatures:
                layout.row().prop(self, "screenType", expand=True)
        
        if self.screenType == "ape":
            self.drawApe(context)
        else:
            layout.label(text="存储下载的 OpenStreetMap 和地形文件的目录:")
            layout.prop(self, "dataDir")
            
            if blenderApp.app.isPro:
                layout.label(text="包含资产的目录(building_materials.blend, vegetation.blend):")
                layout.prop(self, "assetsDir")
            
            layout.separator()
            layout.label(text="粘贴一个或多个访问令牌以获取卫星图像:")
            
            split = layout.split(factor=0.9)
            split.prop(self, "arcgisAccessToken")
            split.operator("blosm.get_arcgis_token", text="获取它!")
            
            split = layout.split(factor=0.9)
            split.prop(self, "mapboxAccessToken")
            split.operator("blosm.get_mapbox_token", text="获取它!")
            
            split = layout.split(factor=0.9)
            split.prop(self, "googleMapsApiKey")
            split.operator("blosm.get_google_maps_api_key", text="获取它!")
            
            layout.separator()
            layout.box().label(text="高级设置:")
            # Extensions might come later
            #layout.operator("blosm.load_extensions", text="加载扩展")
            layout.prop(self, "osmServer")
            
            if blenderApp.app.isPro:
                layout.prop(self, "enableExperimentalFeatures", text="启用实验性功能")

blenderApp.app.addonName = BlosmPreferences.bl_idname


class BLOSM_OT_GetArcgisToken(bpy.types.Operator):
    bl_idname = "blosm.get_arcgis_token"
    bl_label = ""
    bl_description = "获取 ArcGIS API密钥"
    bl_options = {'INTERNAL'}
    
    url = "https://location.arcgis.com/sign-up/"
    
    def execute(self, context):
        import webbrowser
        webbrowser.open_new_tab(self.url)
        return {'FINISHED'}


class BLOSM_OT_GetMapboxToken(bpy.types.Operator):
    bl_idname = "blosm.get_mapbox_token"
    bl_label = ""
    bl_description = "获取 Mapbox访问令牌"
    bl_options = {'INTERNAL'}
    
    url = "https://www.mapbox.com/account/access-tokens"
    
    def execute(self, context):
        import webbrowser
        webbrowser.open_new_tab(self.url)
        return {'FINISHED'}


class BLOSM_OT_GetGoogleMapsApiKey(bpy.types.Operator):
    bl_idname = "blosm.get_google_maps_api_key"
    bl_label = ""
    bl_description = "获取 Google 3D Tiles密钥"
    bl_options = {'INTERNAL'}
    
    url = "https://developers.google.com/maps/documentation/tile/get-api-key"
    
    def execute(self, context):
        import webbrowser
        webbrowser.open_new_tab(self.url)
        return {'FINISHED'}


class BLOSM_OT_GetProVersion(bpy.types.Operator):
    bl_idname = "blosm.get_pro_version"
    bl_label = ""
    bl_description = "获取 Blosm 专业版"
    bl_options = {'INTERNAL'}
    
    url = "https://prochitecture.com/blosm/pro/"
    
    def execute(self, context):
        import webbrowser
        webbrowser.open_new_tab(self.url)
        return {'FINISHED'}

"""
class BLOSM_OT_LoadExtensions(bpy.types.Operator):
    bl_idname = "blosm.load_extensions"
    bl_label = ""
    bl_description = "扫描 Blender 插件，查找 Blosm 扩展并加载它们"
    bl_options = {'INTERNAL'}
    
    def execute(self, context):
        numExtensions = blednerApp.app.loadExtensions(context)
        self.report({'INFO'},
            "未找到扩展" if not numExtensions else\
            ("已加载 1 个扩展" if numExtensions==1 else "已加载 %s 个扩展" % numExtensions)
        )
        return {'FINISHED'}
"""


class BLOSM_OT_ImportData(bpy.types.Operator):
    """Import data: OpenStreetMap or terrain"""
    bl_idname = "blosm.import_data"  # important since its how bpy.ops.blosm.import_data is constructed
    bl_label = "Blosm"
    bl_description = "导入选定类型的数据(OpenStreetMap、Google 3D Tiles、地形等)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        a = blenderApp.app
        dataType = context.scene.blosm.dataType
        
        self.setup(context, a.addonName)
        
        a.projection = None
        a.setAttributes(context)
        
        if dataType == "osm":
            return self.importOsm(context)
        elif dataType == "terrain":
            return self.importTerrain(context)
        elif dataType == "overlay":
            return self.importOverlay(context)
        elif dataType == "gpx":
            return self.importGpx(context)
        elif dataType == "3d-tiles":
            return self.import3dTiles(context)
        elif dataType == "geojson":
            return self.importGeoJson(context)
        
        return {'FINISHED'}

    def setup(self, context, addonName):
        # check if the file <setup_execute.py> is available
        setup_function = self.loadSetupScript(
            os.path.join(os.path.dirname(os.path.realpath(__file__)), "setup_execute.py"),
            reportError=False
        )
        if setup_function:
            setup_function(context, addonName)
    
    def importOsm(self, context):
        a = blenderApp.app
        addon = context.scene.blosm
        
        try:
            a.initOsm(self, context)
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        createFlatTerrain = a.mode is a.realistic and a.forests
        forceExtentCalculation = createFlatTerrain and a.osmSource == "file"
        
        setupScript = addon.setupScript
        if setupScript:
            setup_function = self.loadSetupScript(setupScript, reportError=True)
            if not setup_function:
                return {'CANCELLED'}
        else:
            if a.mode is a.realistic:
                if a.enableExperimentalFeatures:
                    from .setup.realistic_dev import setup as setup_function
                else:
                    from .setup.premium_default import setup as setup_function
            else:
                from .setup.base import setup as setup_function
        
        scene = context.scene
        
        self.setObjectMode(context)
        bpy.ops.object.select_all(action='DESELECT')
        
        osm = Osm(a)
        setup_function(a, osm)
        a.createLayers(osm)
        
        setLatLon = False
        if "lat" in scene and "lon" in scene and a.relativeToInitialImport:
            osm.setProjection(scene["lat"], scene["lon"])
        elif a.osmSource == "server":
            osm.setProjection( (a.minLat+a.maxLat)/2., (a.minLon+a.maxLon)/2. )
            setLatLon = True
        else:
            # This is the case if <a.osmSource == "file"> and if the first condition is not true
            setLatLon = True
        
        osm.parse(a.osmFilepath, forceExtentCalculation=forceExtentCalculation)
        if a.loadMissingMembers and a.incompleteRelations:
            try:
                a.loadMissingWays(osm)
            except Exception as e:
                self.report({'ERROR'}, "出现错误: " + str(e))
                a.loadMissingMembers = False
            a.processIncompleteRelations(osm)
            if not osm.projection:
                # <osm.projection> wasn't set so far if there were only incomplete relations that
                # satisfy <osm.conditions>.
                # See also the comments in <parse.osm.__init__.py>
                # at the end of the method <osm.parse(..)>
                osm.setProjection( (osm.minLat+osm.maxLat)/2., (osm.minLon+osm.maxLon)/2. )
        
        if forceExtentCalculation:
            a.minLat = osm.minLat
            a.maxLat = osm.maxLat
            a.minLon = osm.minLon
            a.maxLon = osm.maxLon
        
        # Check if have a terrain Blender object set
        # At this point <a.projection> is set, so we can set the terrain
        a.setTerrain(
            context,
            createFlatTerrain = createFlatTerrain,
            createBvhTree = True
        )
        
        a.initLayers()
        
        a.process()
        a.render()
        
        # Set <lon> and <lat> attributes for <scene> if necessary.
        # <osm.projection> is set in <osm.setProjection(..)> along with <osm.lat> and <osm.lon>
        # So we test if <osm.projection> is set, that also means that <osm.lat> and <osm.lon> are also set.
        if setLatLon and osm.projection:
            # <osm.lat> and <osm.lon> have been set in osm.parse(..)
            self.setCenterLatLon(context, osm.lat, osm.lon)
        
        a.clean()
        
        return {'FINISHED'}
    
    def getCenterLatLon(self, context):
        a = blenderApp.app
        scene = context.scene
        if "lat" in scene and "lon" in scene and a.relativeToInitialImport:
            lat = scene["lat"]
            lon = scene["lon"]
            setLatLon = False
        else:
            lat = (a.minLat+a.maxLat)/2.
            lon = (a.minLon+a.maxLon)/2.
            setLatLon = True
        return lat, lon, setLatLon
    
    def setCenterLatLon(self, context, lat, lon):
        context.scene["lat"] = lat
        context.scene["lon"] = lon
    
    def loadSetupScript(self, setupScript, reportError):
        setupScript = os.path.realpath(bpy.path.abspath(setupScript))
        if not os.path.isfile(setupScript):
            if reportError:
                self.report({'ERROR'},
                    "脚本文件不存在"
                )
            return None
        import importlib.util
        moduleName = os.path.splitext(os.path.basename(setupScript))[0]
        try:
            spec = importlib.util.spec_from_file_location(moduleName, setupScript)
            module = importlib.util.module_from_spec(spec)
            sys.modules[moduleName] = module
            spec.loader.exec_module(module)
            return module.setup
        except Exception:
            self.report({'ERROR'},
                "无法执行设置脚本! 请查看 Blender 控制台中的错误消息!"
            )
            return None
    
    def importTerrain(self, context):
        a = blenderApp.app
        try:
            a.initTerrain(context)
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        lat, lon, setLatLon = self.getCenterLatLon(context)
        a.setProjection(lat, lon)
        
        a.importTerrain(context)
        
        # set the custom parameters <lat> and <lon> to the active scene
        if setLatLon:
            self.setCenterLatLon(context, lat, lon)
        return {'FINISHED'}
    
    def importOverlay(self, context):
        a = blenderApp.app
        blosm = context.scene.blosm
        
        # find the Blender area holding 3D View
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                a.area = area
                break
        else:
            a.area = None
            
        lat, lon, setLatLon = self.getCenterLatLon(context)
        a.setProjection(lat, lon)
        
        try:
            a.initOverlay(context)
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        terrainObject = context.scene.objects.get(blosm.terrainObject)
        
        minLon, minLat, maxLon, maxLat = a.getExtentFromObject(terrainObject, context)\
            if terrainObject else\
            (a.minLon, a.minLat, a.maxLon, a.maxLat)
        
        a.overlay.prepareImport(minLon, minLat, maxLon, maxLat)
        
        if blosm.commandLineMode:
            hasTiles = True
            while hasTiles:
                hasTiles = blenderApp.app.overlay.importNextTile()
            if blenderApp.app.overlay.finalizeImport():
                self.report({'INFO'}, "覆盖层导入完成!")
            else:
                self.report({'ERROR'}, "可能是瓦片服务器出了问题!")
        else:
            bpy.ops.blosm.control_overlay()
        
        # set the custom parameters <lat> and <lon> to the active scene
        if setLatLon:
            self.setCenterLatLon(context, lat, lon)
        
        return {'FINISHED'}
    
    def import3dTiles(self, context):
        from .threed_tiles.manager import BaseManager
        from .threed_tiles.blender import BlenderRenderer
        
        addon = context.scene.blosm
        google3dTiles = addon.threedTilesSource == "google"

        if not blenderApp.app.isPro and google3dTiles and addon.lodOf3dTiles == "lod6":
            def _draw_pro_popup(self, context):
                self.layout.label(text="此级别的细节仅在专业版中可用")
                self.layout.separator()
                self.layout.operator("blosm.get_pro_version", text="获取专业版!")

            bpy.context.window_manager.popup_menu(
                _draw_pro_popup,
                title="Blosm",
                icon='INFO'
            )
            return {'CANCELLED'}
        
        renderer = BlenderRenderer(
            "Google 3D Tiles" if google3dTiles else "3D Tiles",
            addon.join3dTilesObjects,
            addon.instanceName
        )
        manager = BaseManager(
            "https://tile.googleapis.com/v1/3dtiles/root.json" if google3dTiles else addon.threedTilesUrl,
            renderer
        )
        
        manager.cacheJsonFiles = addon.cacheJsonFiles
        manager.cache3dFiles = addon.cache3dFiles
        
        a = blenderApp.app
        try:
            a.init3dTiles(context, manager, '')
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        manager.centerLat, manager.centerLon, setLatLonHeight = self.getCenterLatLon(context)
        
        if not setLatLonHeight and "height_offset" in context.scene:
            renderer.heightOffset = context.scene["height_offset"]
        else:
            renderer.calculateHeightOffset = True
        
        result = manager.render(a.minLon, a.minLat, a.maxLon, a.maxLat)
        
        if len(result) == 1:
            # a critical error happend
            self.report({'ERROR'}, result[0])
            return {'CANCELLED'}
        
        numImportedTiles, errors = result
        if numImportedTiles:
            if setLatLonHeight:
                context.scene["lat"] = manager.centerLat
                context.scene["lon"] = manager.centerLon
            
            if renderer.calculateHeightOffset:
                context.scene["height_offset"] = renderer.heightOffset
                
            self.report(
                {'INFO'},
                "已导入 %s 个 3D Tiles。导入过程中发生 %s 个错误。 " % (numImportedTiles, len(errors)) +\
                "请查看系统控制台。"\
                    if errors else\
                    "成功导入 %s 个 3D Tiles。" % numImportedTiles
            )
        else:
            self.report(
                {'ERROR'},
                "未导入任何 3D Tiles。导入过程中发生 %s 个错误。 " % len(errors) +\
                "请查看系统控制台。"
            )
        
        if errors:
            for error in errors:
                print(error)
        
        return {'FINISHED'} if numImportedTiles else {'CANCELLED'}
    
    def importGpx(self, context):
        from .parse.gpx import Gpx
        from .gpx import GpxRenderer
        
        a = blenderApp.app
        try:
            a.initGpx(context, BlosmPreferences.bl_idname)
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        scene = context.scene
        
        self.setObjectMode(context)
        bpy.ops.object.select_all(action='DESELECT')
        
        gpx = Gpx(a)
        
        if "lat" in scene and "lon" in scene and a.relativeToInitialImport:
            gpx.setProjection(scene["lat"], scene["lon"])
            setLatLon = False
        else:
            setLatLon = True
        
        gpx.parse(a.gpxFilepath)
        
        # check if have a terrain Blender object set
        a.setTerrain(
            context,
            createFlatTerrain = False,
            createBvhTree = False
        )
        
        GpxRenderer(a).render(gpx)
        
        # setting <lon> and <lat> attributes for <scene> if necessary
        if setLatLon:
            # <gpx.lat> and <gpx.lon> have been set in gpx.parse(..)
            self.setCenterLatLon(context, gpx.lat, gpx.lon)
        return {'FINISHED'}

    def importGeoJson(self, context):
        from .parse.geojson import GeoJson
        
        a = blenderApp.app
        addon = context.scene.blosm
        
        try:
            a.initGeoJson(self, context)
        except Exception as e:
            self.report({'ERROR'}, "出现错误: " + str(e))
            return {'CANCELLED'}
        
        createFlatTerrain = a.mode is a.realistic and a.forests
        forceExtentCalculation = createFlatTerrain
        
        # check if have a terrain Blender object set
        a.setTerrain(
            context,
            createFlatTerrain = createFlatTerrain,
            createBvhTree = True
        )
        
        setupScript = addon.setupScript
        if setupScript:
            setup_function = self.loadSetupScript(setupScript, reportError=True)
            if not setup_function:
                return {'CANCELLED'}
        else:
            if a.mode is a.realistic:
                from .setup.premium_default import setup as setup_function
            else:
                from .setup.geojson_base import setup as setup_function
        
        scene = context.scene
        
        self.setObjectMode(context)
        bpy.ops.object.select_all(action='DESELECT')
        
        data = GeoJson(a)
        setup_function(a, data)
        a.createLayers(data)
        
        setLatLon = False
        if "lat" in scene and "lon" in scene and a.relativeToInitialImport:
            a.setProjection(scene["lat"], scene["lon"])
        elif a.coordinatesAsFilter:
            a.setProjection( (a.minLat+a.maxLat)/2., (a.minLon+a.maxLon)/2. )
        else:
            setLatLon = True
        
        data.parse(a.osmFilepath, forceExtentCalculation=forceExtentCalculation)
        
        if forceExtentCalculation:
            a.minLat = data.minLat
            a.maxLat = data.maxLat
            a.minLon = data.minLon
            a.maxLon = data.maxLon
        
        a.initLayers()
        
        a.process()
        a.render()
        
        # setting <lon> and <lat> attributes for <scene> if necessary
        if setLatLon:
            # <osm.lat> and <osm.lon> have been set in osm.parse(..)
            self.setCenterLatLon(context, data.lat, data.lon)
        
        a.clean()
        
        return {'FINISHED'}
    
    def setObjectMode(self, context):
        scene = context.scene
        # setting active object if there is no active object
        if context.mode != "OBJECT":
            # if there is no object in the scene, only "OBJECT" mode is available
            if not context.view_layer.objects.active:
                context.view_layer.objects.active = scene.objects[0]
            bpy.ops.object.mode_set(mode="OBJECT")
        # Also deselect the active object since the operator
        # <bpy.ops.object.select_all(action='DESELECT')> does not affect hidden objects and
        # the hidden active object
        if context.view_layer.objects.active:
            context.view_layer.objects.active.select_set(False)


class BLOSM_OT_ControlOverlay(bpy.types.Operator):
    bl_idname = "blosm.control_overlay"
    bl_label = ""
    bl_description = "控制覆盖层导入并在 3D 视图中显示进度"
    bl_options = {'INTERNAL'}
    
    lineWidth = 70 # in characters

    def modal(self, context, event):
        if event.type == 'TIMER':
            hasTiles = blenderApp.app.overlay.importNextTile()
            if not hasTiles:
                self.stop(context)
                if blenderApp.app.overlay.finalizeImport():
                    self.report({'INFO'}, "覆盖层导入完成!")
                else:
                    self.report({'ERROR'}, "可能是瓦片服务器出了问题!")
                # cleanup
                blenderApp.app.area = None
                return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def execute(self, context):
        wm = context.window_manager
        
        self._drawHandle = bpy.types.SpaceView3D.draw_handler_add(
            self.drawMessage,
            tuple(),
            'WINDOW',
            'POST_PIXEL'
        )
        
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}

    def stop(self, context):
        context.window_manager.event_timer_remove(self._timer)
        bpy.types.SpaceView3D.draw_handler_remove(self._drawHandle, 'WINDOW')
        blenderApp.app.stateMessage = None
        self._timer = None
        self._drawHandle = None

    def drawMessage(self):
        message = blenderApp.app.stateMessage
        if message:
            # draw message
            fontId = 0
            blf.color(fontId, 0., 1., 0., 1.)
            if len(message)<=self.lineWidth:
                self.drawLine(message, 60)
            else:
                for i,line in enumerate(reversed(textwrap.wrap(message, self.lineWidth))):
                    self.drawLine(line, 60+35*i)
    
    def drawLine(self, content, yPosition):
        fontId = 0
        blf.position(fontId, 15, yPosition, 0)
        blf.size(fontId, 20)
        blf.draw(fontId, content)
    
    def setHeaderText(self, context):
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                area.header_text_set(blenderApp.app.stateMessage)
                blenderApp.app.stateMessage = ''
                return


_classes = (
    BlosmPreferences,
    BLOSM_OT_GetArcgisToken,
    BLOSM_OT_GetMapboxToken,
    BLOSM_OT_GetGoogleMapsApiKey,
    BLOSM_OT_GetProVersion,
    #BLOSM_OT_LoadExtensions,
    BLOSM_OT_ImportData,
    BLOSM_OT_ControlOverlay
)

def register():
    for c in _classes:
        bpy.utils.register_class(c)
    gui.register()
    ape.register()
    if blenderApp.app.has(Keys.mode3dRealistic):
        from .import realistic
        realistic.register()
    # Pro-only: register optional baking tools if available
    if blenderApp.app.isPro:
        try:
            from util.blender_extra import baking as _baking
            if hasattr(_baking, 'register'):
                _baking.register()
        except Exception:
            # optional module; ignore if missing
            pass

def unregister():
    for c in _classes:
        bpy.utils.unregister_class(c)
    gui.unregister()
    ape.unregister()
    if blenderApp.app.has(Keys.mode3dRealistic):
        from . import realistic
        realistic.unregister()
    if blenderApp.app.isPro:
        try:
            from .util.blender_extra import baking as _baking
            if hasattr(_baking, 'unregister'):
                _baking.unregister()
        except Exception:
            pass
