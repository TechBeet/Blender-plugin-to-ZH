"""
This file is a part of Blosm addon for Blender.
Copyright (C) 2014-2023 Vladimir Elistratov, Alain (al1brn)
prokitektura+support@gmail.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import bpy
import os, math, webbrowser, importlib.util, importlib
from bpy.app.handlers import persistent
from ..app.blender import app
from ..defs import Keys

_has3dRealistic = app.has(Keys.mode3dRealistic)

if _has3dRealistic:
    from ..realistic.material.renderer import FacadeWithColor


def getDataTypes():
        items = [
            ("osm", "OpenStreetMap", "OpenStreetMap"),
            ("terrain", "地形", "地形"),
            ("overlay", "图像叠加", "地形的图像叠加，例如卫星图像或地图"),
            ("3d-tiles", "3D Tiles", "Google 等提供商的逼真 3D Tiles。" +\
                "3D Tiles 是开放地理空间联盟 (OGC) 的开放标准，" +\
                "用于流式传输大规模 3D 地理空间内容，如摄影测量和 3D 建筑"
            ),
            ("gpx", "GPX", "GPX 轨迹")
        ]
        if app.has(Keys.geojson):
            items.append(("geojson", "GeoJson", "GeoJson"))
        return items


_blenderMaterials = (
    ("appartments", "fo"),
    ("appartments", "fs"),
    ("office", "fo"),
    ("office", "fs"),
    ("glass", "fs"),
    ("neoclassical", "fo"),
    ("neoclassical", "fs"),
    ("brick", "ms"),
    ("plaster", "ms"),
    ("metal", "ms"),
    ("roof_tiles", "ms"),
    ("concrete", "ms"),
    ("gravel", "ms")
)

# default number of levels and its relative weight
_defaultLevels = (
    (4, 10),
    (5, 40),
    (6, 10)
)


def getBlenderMaterials(self, context):
    materialType = context.scene.blosm.materialType
    return tuple((m[0], m[0], m[0]) for m in _blenderMaterials if m[1] == materialType)


_gnSetups2d = [('-', '', '')]
def updateGnBlendFile2d(self, context):
    _gnSetups2d.clear()
    
    filepath = os.path.realpath(
        bpy.path.abspath(self.gnBlendFile2d)
    )
    if os.path.isfile(filepath):
        with bpy.data.libraries.load(filepath) as (data_from, data_to):
            if data_from.node_groups:
                _gnSetups2d.extend((gnSetup, gnSetup, gnSetup) for gnSetup in data_from.node_groups)
    else:
        _gnSetups2d.append(('-', '', ''))
        self.gnSetup2d = '-'


def getGnSetups2d(self, context):
    return _gnSetups2d


def addDefaultLevels():
    defaultLevels = bpy.context.scene.blosm.defaultLevels
    if not defaultLevels:
        for n, w in _defaultLevels:
            e = defaultLevels.add()
            e.levels = n
            e.weight = w

# This handler is needed to set the defaults for <context.scene.blosm.defaultLevels>
# just after the addon registration
def _onRegister(scene):
    addDefaultLevels()
    # the handler isn't needed anymore, so we remove it
    bpy.app.handlers.scene_update_post.remove(_onRegister)
def _onRegister280():
    addDefaultLevels()
    return
# This handler is needed to set the defaults for <context.scene.blosm.defaultLevels>
# after each start of Blender or reloading the start-up file via Ctrl N or loading any Blender file.
# That's why the persistent decorator is used
@persistent
def _onFileLoaded(scene):
    addDefaultLevels()


class BLOSM_UL_DefaultLevels(bpy.types.UIList):
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_property):
        row = layout.row()
        row.prop(item, "levels")
        row.prop(item, "weight")


class BlosmDefaultLevelsEntry(bpy.types.PropertyGroup):
    levels: bpy.props.IntProperty(
        subtype='UNSIGNED',
        min = 1,
        max = 50,
        default = 5,
        description="默认楼层数"
    )
    weight: bpy.props.IntProperty(
        subtype='UNSIGNED',
        min = 1,
        max = 100,
        default = 10,
        description="默认楼层数的权重，范围在1到100之间"
    )


class BLOSM_OT_ReloadAssetPackageList(bpy.types.Operator):
    bl_idname = "blosm.reload_asset_package_list"
    bl_label = "重新加载资产包列表"
    bl_description = "重新加载资产包列表"
    bl_options = {'INTERNAL'}
    
    def invoke(self, context, event):
        # check if all needed paths do exist
        assetsDir = app.getAssetsDir(context)
        try:
            app.validateAssetsDir(assetsDir)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        
        # additional validation
        if not os.path.isfile( os.path.join(assetsDir, "asset_packages.json") ):
            self.report({'ERROR'}, "资源目录不包含文件 \"asset_packages.json\"")
            _enumAssetPackages.clear()
            return {'CANCELLED'}
        
        if len( app.getAssetPackageList(assetsDir) ) == 1:
            self.report({'WARNING'}, "只有默认资产包。使用资产包编辑器添加更多资产包")
        
        global _loadAssetPackages
        _loadAssetPackages = True
        return {'FINISHED'}


class BLOSM_OT_SelectExtent(bpy.types.Operator):
    bl_idname = "blosm.select_extent"
    bl_label = "选择"
    bl_description = "在地理地图上为您的兴趣区域选择范围"
    bl_options = {'INTERNAL'}
    
    url = "http://prochitecture.com/blender-osm/extent/"
    
    def invoke(self, context, event):
        bv = bpy.app.version
        av = app.version
        # premium due to legacy reasons on the web side
        isPro = "高级版" if app.isPro else ""
        webbrowser.open_new_tab(
            "%s?blender_version=%s.%s&addon=blosm&addon_version=%s%s.%s.%s" %
            (self.url, bv[0], bv[1], isPro, av[0], av[1], av[2])
        )
        return {'FINISHED'}


class BLOSM_OT_PasteExtent(bpy.types.Operator):
    bl_idname = "blosm.paste_extent"
    bl_label = "粘贴"
    bl_description = "从剪贴板粘贴从地理地图上选择的兴趣区域范围"
    bl_options = {'INTERNAL', 'UNDO'}
    
    def invoke(self, context, event):
        addon = context.scene.blosm
        coords = context.window_manager.clipboard
        
        if not coords:
            self.report({'ERROR'}, "没有可粘贴的内容！")
            return {'CANCELLED'}
        try:
            # parse the string from the clipboard to get coordinates of the extent
            coords = tuple( map(lambda s: float(s), coords[(coords.find('=')+1):].split(',')) )
            if len(coords) != 4:
                raise ValueError
        except ValueError:
            self.report({'ERROR'}, "粘贴的字符串无效！")
            return {'CANCELLED'}
        
        addon.minLon = coords[0]
        addon.minLat = coords[1]
        addon.maxLon = coords[2]
        addon.maxLat = coords[3]
        return {'FINISHED'}


class BLOSM_OT_ExtentFromActive(bpy.types.Operator):
    bl_idname = "blosm.extent_from_active"
    bl_label = "从活动对象"
    bl_description = "使用活动 Blender 对象的范围"
    bl_options = {'INTERNAL', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        scene = context.scene
        return context.object and context.object.type == "MESH" and "lat" in scene and "lon" in scene
    
    def invoke(self, context, event):
        scene = context.scene
        addon = scene.blosm
        
        if not app.projection:
            from ..util.transverse_mercator import TransverseMercator
            app.projection = TransverseMercator(lat=scene["lat"], lon=scene["lon"])
        
        addon.minLon, addon.minLat, addon.maxLon, addon.maxLat = app.getExtentFromObject(
            context.object,
            context
        )
        
        return {'FINISHED'}


class BLOSM_OT_ReplaceMaterials(bpy.types.Operator):
    bl_idname = "blosm.replace_materials"
    bl_label = "替换材质"
    bl_description = "替换所选对象的材质"
    bl_options = {'INTERNAL', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects
    
    def invoke(self, context, event):
        addon = context.scene.blosm
        if addon.replaceMaterialsWith == "export-ready":
            self.replaceWithExportReadyMaterials(context)
        else: # if addon.replaceMaterialsWith == "custom":
            materialName = addon.replacementMaterial
            if not materialName:
                self.report({'ERROR'}, "未设置替换材质！")
                return {'CANCELLED'}
            elif not materialName in bpy.data.materials:
                self.report({'ERROR'}, "替换材质的名称不正确！")
                return {'CANCELLED'}
            
            templateMaterial = bpy.data.materials[materialName]
            imageTextureNodeName = ''
            if templateMaterial.use_nodes and templateMaterial.node_tree.nodes:
                # # 检查是否有标签为 "基础颜色" 的图像纹理节点
                for node in templateMaterial.node_tree.nodes:
                    if node.type == 'TEX_IMAGE' and node.label == "基础颜色":
                        imageTextureNodeName = node.name
                        break
            self.replaceMaterialsWithTemplate(templateMaterial, imageTextureNodeName, context)
            
        return {'FINISHED'}
    
    def replaceWithExportReadyMaterials(self, context):
        # create a template material for export
        templateMaterial = bpy.data.materials.new("导出用材质")
        templateMaterial.use_nodes = True
        imageTextureNode = templateMaterial.node_tree.nodes.new('ShaderNodeTexImage')
        imageTextureNode.label = "基础颜色"
        imageTextureNode.location = (-300, 300)
        
        # Find the first node of the type <PRINCIPLED_BSDF>
        for principledBsdfNode in templateMaterial.node_tree.nodes:
            if principledBsdfNode.type == 'BSDF_PRINCIPLED':
                break
        
        # create links
        templateMaterial.node_tree.links.new(
            principledBsdfNode.inputs['Base Color'],
            imageTextureNode.outputs['Color']
        )
        
        self.replaceMaterialsWithTemplate(templateMaterial, imageTextureNode.name, context)
    
    def replaceMaterialsWithTemplate(self, templateMaterial, imageTextureNodeName, context):
        for obj in [obj for obj in context.selected_objects if obj.type == 'MESH']:
            for slot in obj.material_slots:
                if slot and slot.material:
                    material = templateMaterial.copy()
                    currentMaterial = slot.material
                    if imageTextureNodeName and currentMaterial.use_nodes and currentMaterial.node_tree.nodes:
                        # find the Image Texture node with the label "基础颜色"
                        for node in currentMaterial.node_tree.nodes:
                            if node.type == 'TEX_IMAGE' and node.label == "基础颜色":
                                material.node_tree.nodes[imageTextureNodeName].image = node.image
                                break
                    slot.material = material


class BLOSM_OT_Gn2d_Info(bpy.types.Operator):
    bl_idname = "blosm.gn2d_info"
    bl_label = "几何节点"
    bl_description = "关于将 Geometry Nodes 应用于导入的建筑足迹的信息"
    bl_options = {'INTERNAL'}
    
    def invoke(self, context, event):
        webbrowser.open_new_tab("https://github.com/vvoovv/blosm/wiki/Applying-Geometry-Nodes-to-Building-Footprints")
        return {'FINISHED'}


class BLOSM_OT_LevelsAdd(bpy.types.Operator):
    bl_idname = "blosm.default_levels_add"
    bl_label = "+"
    bl_description = "添加默认楼层数条目。" +\
        "请输入楼层数及其相对权重（1到100之间）"
    bl_options = {'INTERNAL'}
    
    def invoke(self, context, event):
        context.scene.blosm.defaultLevels.add()
        return {'FINISHED'}


class BLOSM_OT_LevelsDelete(bpy.types.Operator):
    bl_idname = "blosm.default_levels_delete"
    bl_label = "-"
    bl_description = "删除所选的默认楼层数条目"
    bl_options = {'INTERNAL'}
    
    @classmethod
    def poll(cls, context):
        return len(context.scene.blosm.defaultLevels) > 1
    
    def invoke(self, context, event):
        addon = context.scene.blosm
        defaultLevels = addon.defaultLevels
        defaultLevels.remove(addon.defaultLevelsIndex)
        if addon.defaultLevelsIndex >= len(defaultLevels):
            addon.defaultLevelsIndex = 0
        return {'FINISHED'}


class BLOSM_PT_Copyright(bpy.types.Panel):
    bl_label = "版权"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"
    bl_category = "Blosm"
    
    @classmethod
    def poll(cls, context):
        return context.scene.blosm.copyright
    
    def draw(self, context):
        self.layout.label(text = context.scene.blosm.copyright)


class BLOSM_PT_Extent(bpy.types.Panel):
    bl_label = "Blosm"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"
    bl_category = "Blosm"

    def draw(self, context):
        layout = self.layout
        addon = context.scene.blosm
        
        if (addon.dataType == "osm" and addon.osmSource == "server") or\
            (addon.dataType == "overlay" and not bpy.data.objects.get(addon.terrainObject)) or\
            addon.dataType == "terrain" or\
            addon.dataType == "3d-tiles" or\
            (addon.dataType == "geojson" and addon.coordinatesAsFilter):
            box = layout.box()
            row = box.row()
            row.alignment = "CENTER"
            row.label(text="范围:")
            row = box.row(align=True)
            row.operator("blosm.select_extent")
            row.operator("blosm.paste_extent")
            row.operator("blosm.extent_from_active")
            
            split = box.split(factor=0.25)
            split.label(text="")
            split.split(factor=0.67).prop(addon, "maxLat")
            row = box.row()
            row.prop(addon, "minLon")
            row.prop(addon, "maxLon")
            split = box.split(factor=0.25)
            split.label(text="")
            split.split(factor=0.67).prop(addon, "minLat")
        
        box = layout.box()
        row = box.row(align=True)
        row.prop(addon, "dataType", text="")
        row.operator("blosm.import_data", text="导入")


class PanelRealisticTools():#(bpy.types.Panel):
    bl_label = "真实模式"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    #bl_context = "objectmode"
    bl_category = "Blosm"
    
    @classmethod
    def poll(cls, context):
        addon = context.scene.blosm
        return _has3dRealistic and addon.dataType == "osm"\
            and addon.mode == "3Drealistic"
    
    def draw(self, context):
        layout = self.layout
        addon = context.scene.blosm

        layout.prop(addon, "treeDensity")
        
        box = layout.box()
        row = box.row(align=True)
        row.prop(addon, "makeRealisticLayer", text="")
        row.operator("blosm.make_realistic")
        box.operator("blosm.flatten_selected")
        
        layout.operator("blosm.make_polygon")


class BLOSM_PT_Settings(bpy.types.Panel):
    bl_label = "设置"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"
    bl_category = "Blosm"
    
    def draw(self, context):
        addon = context.scene.blosm
        
        dataType = addon.dataType
        if dataType == "osm":
            self.drawOsm(context)
        elif dataType == "terrain":
            self.drawTerrain(context)
        elif dataType == "overlay":
            self.drawOverlay(context)
        elif dataType == "3d-tiles":
            self.draw3dTiles(context)
        elif dataType == "gpx":
            self.drawGpx(context)
        elif dataType == "geojson":
            self.drawOsm(context)
    
    def drawOsm(self, context):
        layout = self.layout
        addon = context.scene.blosm
        mode3dRealistic = _has3dRealistic and addon.mode == "3Drealistic"
        isOsm = addon.dataType == "osm"
        isGeoJson = addon.dataType == "geojson"
        
        box = layout.box()
        if isOsm:
            box.prop(addon, "osmSource", text="导入来源")
        if isGeoJson or addon.osmSource == "file":
            box.prop(addon, "osmFilepath", text="文件")
        if isGeoJson:
            box.prop(addon, "coordinatesAsFilter")
        
        layout.box().prop_search(addon, "terrainObject", context.scene, "objects")
            
        layout.prop(addon, "mode", expand=True)
        
        prefs = context.preferences.addons
        enableExperimentalFeatures = (app.addonName in prefs and prefs[app.addonName].preferences.enableExperimentalFeatures) or not app.addonName in prefs
        
        if enableExperimentalFeatures and mode3dRealistic:

            split = layout.box().split(factor=0.5)
            split.label(text="资产包:")
            row = split.row()
            row.prop(addon, "assetPackage", text='')
            row.operator("blosm.reload_asset_package_list", icon='FILE_REFRESH', text='')
            
            layout.box().prop(addon, "importForExport")
            
            box = layout.box()
            box.box().prop(addon, "buildings")
            
            box = box.box()
            box.prop(addon, "forests", text="导入森林和单独的树木")
            if addon.forests:
                box.prop(addon, "treeDensity")
            
            layout.box().prop(addon, "singleObject")
            
            layout.box().prop(addon, "relativeToInitialImport")
            
            box = layout.box()
            box.label(text = "[高级]:")
            
            split = box.split(factor=0.5)
            split.label(text="脚本:")
            split.prop(addon, "setupScript", text="")
        else:
            if mode3dRealistic:
                box = layout.box()
                box.prop(addon, "buildings")
                if addon.buildings:
                    box.prop(addon, "litWindows")
                    box.separator()
                    self._drawBuildingSettings(box, addon)
                
                # forests and trees
                box = layout.box()
                box.prop(addon, "forests", text="导入森林和单独的树木")
                if addon.forests:
                    box.prop(addon, "treeDensity")
            else:
                box = layout.box()
                box.prop(addon, "buildings")
                box.prop(addon, "water")
                box.prop(addon, "forests")
                box.prop(addon, "vegetation")
                box.prop(addon, "highways")
                box.prop(addon, "railways")
            
            if not mode3dRealistic and addon.mode != "2D":
                self._drawBuildingSettings(layout.box(), addon)
            
            #box.prop(addon, "straightAngleThreshold")
            
            layout.box().prop(addon, "singleObject")
            
            if addon.mode == "2D" and addon.singleObject:
                box = layout.box()
                row = box.row()
                row.label(text="[几何节点]:")
                row.operator("blosm.gn2d_info", text='', icon='QUESTION')
                box.prop(addon, "gnBlendFile2d", text="文件")
                box.prop(addon, "gnSetup2d", text="名称")
                
                if addon.gnSetup2d != '-':
                    self._drawDefaultLevels(box, addon)
            
            layout.box().prop(addon, "relativeToInitialImport")
            
            box = layout.box()
            box.label(text = "[高级]:")
            split = box.split(factor=0.5)
            split.label(text="脚本:")
            split.prop(addon, "setupScript", text="")
    
    def _drawBuildingSettings(self, box, addon):
        split = box.split(factor=0.67)
        split.label(text="默认屋顶形状:")
        split.prop(addon, "defaultRoofShape", text="")
        box.prop(addon, "levelHeight")
        
        self._drawDefaultLevels(box, addon)
    
    def _drawDefaultLevels(self, box, addon):
        column = box.column()
        split = column.split(factor=0.67, align=True)
        split.label(text="默认楼层数:")
        split.operator("blosm.default_levels_add")
        split.operator("blosm.default_levels_delete")
        
        column.template_list(
            "BLOSM_UL_DefaultLevels", "",
            addon, "defaultLevels", addon, "defaultLevelsIndex",
            rows=3
        )
    
    def drawTerrain(self, context):
        addon = context.scene.blosm
        
        self.layout.box().prop(addon, "relativeToInitialImport")
        
        # Vertex reduction: reduction ratio selection + total vertex computation
        count = 3600 // int(addon.terrainResolution)
        lat = int((addon.maxLat - addon.minLat) * count)
        lon = int((addon.maxLon - addon.minLon) * count)
        ratio = int(addon.terrainReductionRatio)
        verts = (lat//ratio+1)*(lon//ratio+1)
        
        box = self.layout.box()
        box.label(text="[高级] 顶点减少")
        box.prop(addon, "terrainReductionRatio")
        box.label(text="顶点数: {:,d}".format(verts))
    
    def drawOverlay(self, context):
        layout = self.layout
        addon = context.scene.blosm
        
        layout.box().prop_search(addon, "terrainObject", context.scene, "objects")
        
        box = layout.box()
        box.prop(addon, "overlayType")
        if addon.overlayType == "custom":
            #box = layout.box()
            box.label(text="在此粘贴覆盖层 URL:")
            box.prop(addon, "overlayUrl")
        
        box = layout.box()
        box.prop(addon, "setOverlayMaterial")
        box.prop(addon, "saveOverlayToFile")
        
        box = self.layout.box()
        box.label(text="[高级]")
        split = box.split(factor=0.7)
        split.label(text="最大瓦片数:")
        split.prop(addon, "maxNumTiles", text='')
        _squreTextureSize = 256 * round( math.sqrt(addon.maxNumTiles) )
        box.label(text="类似方形纹理 {:,d}x{:,d} px".format(_squreTextureSize, _squreTextureSize))
    
    def draw3dTiles(self, context):
        layout = self.layout
        addon = context.scene.blosm
        
        box = layout.box()
        
        box.row().prop(addon, "threedTilesSource", text="来源")
        
        if addon.threedTilesSource == "custom":
            box.label(text="在此粘贴根瓦片 URL:")
            box.prop(addon, "threedTilesUrl")
            box.prop(addon, "geometricError")
        else:
            box.label(text="细节级别:")
            box.prop(addon, "lodOf3dTiles", text='')
        
        layout.prop(addon, "join3dTilesObjects")
        layout.prop(addon, "relativeToInitialImport")
    
    def drawGpx(self, context):
        layout = self.layout
        addon = context.scene.blosm
        
        layout.box().prop(addon, "gpxFilepath", text="文件")
        
        layout.box().prop_search(addon, "terrainObject", context.scene, "objects")
        
        layout.box().prop(addon, "gpxProjectOnTerrain")
        
        layout.box().prop(addon, "relativeToInitialImport")


class BLOSM_PT_Tools(bpy.types.Panel):
    bl_label = "工具"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"
    bl_category = "Blosm"
    
    @classmethod
    def poll(cls, context):
        return context.scene.blosm.dataType == "3d-tiles" and context.selected_objects
    
    def draw(self, context):
        layout = self.layout
        addon = context.scene.blosm
        
        box = layout.box()
        box.label(text="替换材质与")
        box.row().prop(addon, "replaceMaterialsWith", expand=True)
        if addon.replaceMaterialsWith == "custom":
            box.prop_search(addon, "replacementMaterial", bpy.data, "materials")
        box.operator("blosm.replace_materials")

        # Pro-only baking UI (3D Tiles). Show when module is available and active is a mesh
        isPro = app.isPro
        active_mesh = context.object and context.object.type == 'MESH'
        baking_mod = None
        if isPro:
            for name in ('util.blender_extra.baking', 'blosm.util.blender_extra.baking'):
                try:
                    if importlib.util.find_spec(name):
                        baking_mod = importlib.import_module(name)
                        break
                except Exception:
                    continue
        if isPro and baking_mod and active_mesh:
            box = layout.box()
            box.label(text="烘焙: 单一纹理")
            box.prop(addon, "bake_image_size")
            box.split(factor=0.5)
            box.prop(addon, "bake_replace_active")
            box.operator("blosm.bake_to_single_material", text="烘焙")


class BLOSM_PT_BpyProj(bpy.types.Panel):
    bl_label = "投影"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_context = "objectmode"
    bl_category = "Blosm"
    
    @classmethod
    def poll(cls, context):
        return "bpyproj" in context.preferences.addons
    
    def draw(self, context):
        import bpyproj
        bpyproj.draw(context, self.layout)


_loadAssetPackages = False
_enumAssetPackages = []
def getAssetPackages(self, context):
    global _loadAssetPackages
    if _loadAssetPackages:
        # It has been just tested in the operator <blosm.reload_asset_package_list>
        # that the file does exist
        apList = app.getAssetPackageList( app.getAssetsDir(context) )
        _enumAssetPackages.clear()
        _enumAssetPackages.extend(tuple(apInfo) for apInfo in apList)
        _loadAssetPackages = False
    elif not _enumAssetPackages:
        _enumAssetPackages.append(("default", "default", "default"))
    return _enumAssetPackages


class BlosmProperties(bpy.types.PropertyGroup):
    
    commandLineMode: bpy.props.BoolProperty(
        name = "命令行模式",
        description = "该选项指定插件是否在命令行模式下使用",
        default = False
    )
    
    instanceName: bpy.props.StringProperty(
        name = "实例名称",
        description = "运行多个 Blender 实例的实例名称",
        default = ''
    )
    
    terrainObject: bpy.props.StringProperty(
        name = "地形",
        description = "地形的 Blender 对象"
    )
    
    osmSource: bpy.props.EnumProperty(
        name = "从 OpenStreetMap 导入",
        items = (
            ("server", "服务器", "远程服务器"),
            ("file", "文件", "本地磁盘上的文件")
        ),
        description = "从哪里导入 OpenStreetMap 数据：远程服务器或本地磁盘上的文件",
        default = "server"
    )
    
    osmFilepath: bpy.props.StringProperty(
        name = "OpenStreetMap文件",
        subtype = 'FILE_PATH',
        description = "要导入的 OpenStreetMap 文件路径"
    )
    
    dataType: bpy.props.EnumProperty(
        name = "数据",
        items = getDataTypes(),
        description = "导入的数据类型",
        default = "osm"
    )
    
    mode: bpy.props.EnumProperty(
        name = "模式：3D 真实、3D 简单或 2D"
            if _has3dRealistic else
            "模式：3D 或 2D",
        items = (
                ("3Drealistic", "3D 真实", "3D 真实"),
                ("3Dsimple", "3D 简单", "3D 简单"),
                ("2D", "2D", "2D")
            ) if _has3dRealistic else
            (("3Dsimple", "3D", "3D"), ("2D", "2D", "2D")),
        description = ("导入包含纹理和 3D 对象的数据（3D 真实）" +
            "或不包含它们（3D 简单）" +
            "或仅导入 2D 数据")
            if _has3dRealistic else
            "以 3D 或 2D 模式导入数据",
        default = "3Drealistic" if _has3dRealistic else "3Dsimple"
    )
    
    importForExport: bpy.props.BoolProperty(
        name = "导出就绪",
        description = "导入准备好导出到主流 3D 格式的 OpenStreetMap 建筑",
        default = False
    )
    
    # extent bounds: minLat, maxLat, minLon, maxLon
    
    minLat: bpy.props.FloatProperty(
        name = "最小纬度",
        description="要导入范围的最小纬度",
        precision = 4,
        min = -89.,
        max = 89.,
        default= 40.7463 if _has3dRealistic else 51.33
    )

    maxLat: bpy.props.FloatProperty(
        name = "最大纬度",
        description="要导入范围的最大纬度",
        precision = 4,
        min = -89.,
        max = 89.,
        default= 40.7523 if _has3dRealistic else 51.33721
    )

    minLon: bpy.props.FloatProperty(
        name = "最小经度",
        description="要导入范围的最小经度",
        precision = 4,
        min = -180.,
        max = 180.,
        default= -73.9892 if _has3dRealistic else 12.36902
    )

    maxLon: bpy.props.FloatProperty(
        name = "最大经度",
        description="要导入范围的最大经度",
        precision = 4,
        min = -180.,
        max = 180.,
        default= -73.9812 if _has3dRealistic else 12.37983
    )
    
    coordinatesAsFilter: bpy.props.BoolProperty(
        name = "使用坐标作为过滤器",
        description = "使用坐标作为从文件导入的过滤器",
        default = False
    )
    
    buildings: bpy.props.BoolProperty(
        name = "导入建筑",
        description = "导入建筑轮廓",
        default = True
    )
    
    water: bpy.props.BoolProperty(
        name = "导入水体",
        description = "导入水体(河流和湖泊)",
        default = True
    )
    
    forests: bpy.props.BoolProperty(
        name = "导入森林",
        description = "导入森林和林地",
        default = not _has3dRealistic
    )
    
    vegetation: bpy.props.BoolProperty(
        name = "导入其他植被",
        description = "导入其他植被(草地、草甸、灌木)",
        default = True
    )
    
    highways: bpy.props.BoolProperty(
        name = "导入道路和路径",
        description = "导入道路和路径",
        default = True
    )
    
    railways: bpy.props.BoolProperty(
        name = "导入铁路",
        description = "导入铁路",
        default = False
    )
    
    defaultRoofShape: bpy.props.EnumProperty(
        items = (("flat", "flat", "flat shape"), ("gabled", "gabled", "gabled shape")),
        description = "如果 OpenStreetMap 中未设置屋顶形状，则用于建筑的屋顶形状",
        default = "flat"
    )
    
    singleObject: bpy.props.BoolProperty(
        name = "作为单个对象导入",
        description = "将 OSM 对象作为单个 Blender 网格对象导入，而不是单独的对象",
        default = True
    )

    relativeToInitialImport: bpy.props.BoolProperty(
        name = "相对于初始导入",
        description = "如果可用，则相对于初始导入",
        default = True
    )
    
    levelHeight: bpy.props.FloatProperty(
        name = "层高",
        description = "用于 OSM 标签 building:levels 和 building:min_level 的层平均高度(米)",
        default = 3.
    )
    
    defaultLevels: bpy.props.CollectionProperty(type = BlosmDefaultLevelsEntry)
    
    defaultLevelsIndex: bpy.props.IntProperty(
        subtype='UNSIGNED',
        default = 0,
        description = "默认楼层数条目的活动条目索引"
    )
    
    straightAngleThreshold: bpy.props.FloatProperty(
        name = "直角阈值",
        description = "建筑轮廓角度的阈值：何时将其视为直线。" +
            "It may be important for calculation of the longest side of the building outline for a gabled roof.",
        default = 175.5,
        min = 170.,
        max = 179.95,
        step = 10 # i.e. step/100 == 0.1
    )
    
    loadMissingMembers: bpy.props.BoolProperty(
        name = "加载关联关系的成员",
        description = "OSM 文件中不包含关系成员 " +
            "if they are located outside of the OSM file extent. " +
            "Enable this option to load the missiong members of the relations " +
            "either from a local file (if available) or from the server.",
        default = True
    )
    
    subdivide: bpy.props.BoolProperty(
        name = "细分曲线和平面图层",
        description = "细分表示道路和路径的 Blender 曲线并 " +
        "polygons representing flat layers (water, forest, vegetation) " +
        "to project them on the terrain correctly",
        default = True
    )
    
    subdivisionSize: bpy.props.FloatProperty(
        name = "细分大小",
        description = "细分大小(米)",
        default = 10.,
        min = 5.,
        step = 100 # i.e. step/100 == 1.
    )
    
    # Terrain settings
    # SRTM3 data are sampled at either 3 arc-second and contain 1201 lines and 1201 samples
    # or 1 arc-second and contain 3601 lines and 3601 samples
    terrainResolution: bpy.props.EnumProperty(
        name = "分辨率",
        items=(("1", "1 arc-second", "1 arc-second"), ("3", "3 arc-second", "3 arc-second")),
        description="空间分辨率",
        default="1"
    )
    
    terrainPrimitiveType: bpy.props.EnumProperty(
        name = "网格原始类型: 四边形或三角形",
        items=(("quad","quad","quad"),("triangle","triangle","triangle")),
        description="Primitive type used for the terrain mesh: quad or triangle",
        default="quad"
    )

    # Number of vertex reduction
    # The Reduction Ratio is a divider of 1200
    terrainReductionRatio: bpy.props.EnumProperty(
        name = "比率",
        items=(
            ("1","100%","无减少"),
            ("2","25%","Divide par 4"),
            ("5","4%","Divide by 25"),
            ("10","1%","Divide by 100"),
            ("20","0.25%","Divide by 400"),
            ("50","0.04%","Divide by 2500"),
            ("100","0.01%","Divide by 10,000"),
            ("200","0.0025%","Divide by 40,000"),
            ("400","0.0006%","Divide by 160,000"),
            ("600","0.0003%","Divide by 360,000"),
            ("1200","0.0001%","Divide by 1,440,000")
        ),
        description="顶点数量的减少比率",
        default="1"
    )
    
    #
    # Overlay settings
    #
    overlayType: bpy.props.EnumProperty(
        name = "覆盖层",
        items = (
            #("bing-aerial", "Bing Aerial", "Bing Aerial"),
            ("arcgis-satellite", "ArcGIS 卫星", "ArcGIS 卫星"),
            ("mapbox-satellite", "Mapbox 卫星", "Mapbox 卫星"),
            ("osm-mapnik", "OSM Mapnik", "OpenStreetMap Mapnik"),
            ("mapbox-streets", "Mapbox 街道", "Mapbox 街道"),
            ("custom", "自定义URL", "自定义图像覆盖层的 URL 模板")
        ),
        description = "图像覆盖层类型",
        default = "arcgis-satellite"
    )
    
    overlayUrl: bpy.props.StringProperty(
        name = '',
        description = "URL for the custom image overlay. Use {z}/{x}/{y} in the URL or "+
            "Mapbox style URL mapbox://styles/... "+
            "See http://wiki.openstreetmap.org/wiki/Slippy_map_tilenames for details about "+
            "the URL format."
    )
    
    setOverlayMaterial: bpy.props.BoolProperty(
        name = "设置默认材质",
        description = "设置默认的 Cycles 材质和 " +
            "use the image overlay in the \"Image Texture\" node",
        default = True
    )
    
    saveOverlayToFile: bpy.props.BoolProperty(
        name = "保存覆盖层到文件",
        description = "如果选中，则将图像覆盖层保存到本地文件，或 " +
            "pack it to the current .blend file otherwise",
        default = False
    )
    
    maxNumTiles: bpy.props.IntProperty(
        name = "最大覆盖层瓦片数",
        subtype = 'UNSIGNED',
        min = 128,
        default = 256,
        description = "最大覆盖层瓦片数。每个瓦片的尺寸为 256x256 像素"
    )
    
    ####################################
    # Settings for the 3D Tiles import
    ####################################
    
    threedTilesSource: bpy.props.EnumProperty(
        name = "3D Tiles来源",
        items = (
            ("google", "Google", "Google 的 3D Tiles(类似于 Google Maps 或 Google Earth 中的 3D 内容)"),
            ("custom", "自定义", "由自定义根瓦片 URL 定义的 3D Tiles")
        ),
        description = "3D Tiles来源",
        default = "google"   
    )
    
    threedTilesUrl: bpy.props.StringProperty(
        name = '',
        description = "根瓦片的 URL"
    )
    
    lodOf3dTiles: bpy.props.EnumProperty(
        name = "细节级别",
        items = (
            ("lod1", "整个城市", "整个城市"),
            ("lod2", "区域", "区域"),
            ("lod3", "建筑群组", "建筑群组"),
            ("lod4", "单独建筑", "单独建筑"),
            ("lod5", "带细节的建筑", "带细节的建筑"),
            ("lod6", "更多细节的建筑", "包含更多细节的建筑")\
                            if app.isPro else\
                            ("lod6", "[专业版] 更多细节的建筑", "在专业版中：包含更多细节的建筑")
                    ),
        description = "选择细节级别 (LoD)",
        default = "lod3"
    )
    
    geometricError: bpy.props.FloatProperty(
        name = "几何误差",
        subtype = 'UNSIGNED',
        description = "几何误差越小，导入的场景越详细。\n\n瓦片树中第一个几何误差等于或小于给定值的瓦片将被导入。\n\n尝试将当前几何误差值除以二，以获得更详细的场景",
        default = 30.
    )
    
    join3dTilesObjects: bpy.props.BoolProperty(
        name = "合并3D Tiles对象",
        description = "合并 3D Tiles 对象并删除重复顶点",
        default = True
    )
    
    copyright: bpy.props.StringProperty(
        name = "版权信息",
        description = "导入内容的版权",
        default = ''
    )
    
    cacheJsonFiles: bpy.props.BoolProperty(
        name = "缓存JSON文件",
        description = "缓存定义瓦片集的 JSON 文件",
        default = False
    )
    
    cache3dFiles: bpy.props.BoolProperty(
        name = "缓存3D文件",
        description = "缓存 3D 文件(例如 .glb 格式)",
        default = False
    )
    
    replaceMaterialsWith: bpy.props.EnumProperty(
        name = "替换材质为",
        items = (
            ("export-ready", "导出就绪", "替换为导出就绪的材质"),
            ("custom", "自定义", "替换为基于给定材质的自定义材质")
        ),
        description = "替换所选对象的材质",
        default = "export-ready"
    )
    
    replacementMaterial: bpy.props.StringProperty(
        name = "材质",
        description = "用于替换所选对象材质的自定义材质"
    )
    
    ####################################
    # Settings for the GPX track import
    ####################################
    
    gpxFilepath: bpy.props.StringProperty(
        name = "GPX文件",
        subtype = 'FILE_PATH',
        description = "要导入的 GPX 文件路径"
    )
    
    gpxProjectOnTerrain: bpy.props.BoolProperty(
        name = "将 GPX 轨迹投影到地形",
        description="Project GPX-track on the terrain if checked or use elevations from GPX-track for z-coordinate otherwise",
        default=True
    )
    
    gpxImportType: bpy.props.EnumProperty(
        name = "作为曲线或网格导入",
        items = (
            ("curve", "曲线", "Blender 曲线"),
            ("mesh", "网格", "Blender 网格")
        ),
        description = "作为 Blender 曲线或网格导入",
        default = "curve"
    )
    
    ####################################
    # Settings for the realistic 3D mode
    ####################################
    setupScript: bpy.props.StringProperty(
        name = "脚本",
        subtype = 'FILE_PATH',
        description = "脚本路径。留空为默认。"
    )
    
    assetsDir: bpy.props.StringProperty(
        name = "资产目录",
        subtype = 'DIR_PATH',
        description = "资产目录(building_materials.blend、vegetation.blend)。 " +
            "覆盖插件设置中的目录"
    )
    
    treeDensity: bpy.props.IntProperty(
        name = "每公顷树木数",
        description = "每公顷(10,000 平方米)的树木数量， " +
            "例如 100m x 100m 的地块) 用于森林",
        min = 1,
        subtype = 'UNSIGNED',
        default = 500
    )
    
    makeRealisticLayer: bpy.props.EnumProperty(
        name = "\"Make realistic\" layer",
        items = (
            ("water", "水", "水"),
            ("forest", "森林", "森林"),
            ("meadow", "草地", "草地")
        ),
        description = "\"真实模式\"操作符的图层",
        default = "water"
    )
    
    litWindows: bpy.props.IntProperty(
        name = "灯窗百分比",
        description = "建筑的灯窗百分比",
        min = 0,
        max = 100,
        subtype = 'UNSIGNED',
        default = 0,
        update = FacadeWithColor.updateLitWindows if _has3dRealistic else None
    )
    
    assetPackage: bpy.props.EnumProperty(
        name = "资产包",
        items = getAssetPackages,
        description = "场景导入使用的资产包"
    )
    
    #    
    # A group of properties for Blender material utilities
    #
    
    materialType: bpy.props.EnumProperty(
        name = "材质类型",
        items = (
            # <fo> stands for 'facade with overlays'
            ("fo", "带窗口覆盖的立面", 
                "用于墙面装饰的无缝纹理，窗户通过覆盖纹理放置在墙上"),
            # <fs> stands for 'facade seamless'
            ("fs", "无缝立面",
                "带窗户的无缝立面纹理"),
            # <ms> stands for 'material seamless'
            ("ms", "无缝外墙板",
                "墙壁和屋顶的无缝外墙板纹理")
            #("custom", "custom script", "Custom script")
        ),
        description = "要创建的 Blender 材质类型",
        default = "fo"
    )
    
    blenderMaterials: bpy.props.EnumProperty(
        name = "Blender 材质",
        items = getBlenderMaterials,
        description = "要创建的 Blender 材质组"
    )
    
    wallTexture: bpy.props.StringProperty(
        name = "墙面纹理",
        subtype = 'FILE_PATH',
        description = "必须列在 Blender 文本数据块 \"wall_textures\" 中的墙面纹理路径"
    )
    
    listOfTextures: bpy.props.StringProperty(
        name = "纹理列表",
        description = "要从 textures.com 下载的纹理列表"
    )
    
    materialScript: bpy.props.StringProperty(
        name = "脚本",
        description = "使用选定纹理生成材质的 Python 脚本"
    )
    
    #
    # Properties for a Geometry Nodes setup applied to building footprints
    #
    gnBlendFile2d: bpy.props.StringProperty(
        name = "带有几何节点的文件",
        subtype = 'FILE_PATH',
        description = "带有应用于建筑足迹的几何节点设置的 Blender 文件路径",
        update = updateGnBlendFile2d
    )
    
    gnSetup2d: bpy.props.EnumProperty(
        name = "几何节点设置",
        items = getGnSetups2d,
        description = "应用于建筑足迹的几何节点设置"
    )

    # --- Pro baking settings (3D Tiles Tools) ---
    bake_image_size: bpy.props.IntProperty(
        name = "图像大小",
        description = "正方形烘焙分辨率(像素)",
        subtype='PIXEL',
        min=128, max=16384, default=4096
    )
    bake_margin_px: bpy.props.IntProperty(
        name = "烘焙边距(像素)",
        description = "烘焙边距以避免渗色",
        min=0, max=64, default=2
    )
    bake_uv_margin: bpy.props.FloatProperty(
        name = "UV 边距",
        description = "UV 包装边距(相对 0..1)",
        min=0.0, max=0.05, default=0.001, precision=4
    )
    bake_cage_extrusion: bpy.props.FloatProperty(
        name = "笼子挤出",
        description = "所选到活动的笼子挤出距离",
        min=0.0, max=10.0, default=0.1, precision=3
    )
    bake_replace_active: bpy.props.BoolProperty(
        name = "替换活动对象",
        description = "用烘焙结果替换活动对象",
        default = False
    )


_classes = (
    BLOSM_UL_DefaultLevels,
    BlosmDefaultLevelsEntry,
    BLOSM_OT_ReloadAssetPackageList,
    BLOSM_OT_SelectExtent,
    BLOSM_OT_PasteExtent,
    BLOSM_OT_ExtentFromActive,
    BLOSM_OT_ReplaceMaterials,
    BLOSM_OT_Gn2d_Info,
    BLOSM_OT_LevelsAdd,
    BLOSM_OT_LevelsDelete,
    BLOSM_PT_Copyright,
    BLOSM_PT_Extent,
    BLOSM_PT_Settings,
    BLOSM_PT_Tools,
    BLOSM_PT_BpyProj,
    BlosmProperties
)

def register():
    for c in _classes:
        bpy.utils.register_class(c)
    # a group for all GUI attributes related to Blosm
    bpy.types.Scene.blosm = bpy.props.PointerProperty(type=BlosmProperties)
    bpy.app.timers.register(_onRegister280, first_interval=2)
    # see the notes near the code for <_onFileLoaded>
    bpy.app.handlers.load_post.append(_onFileLoaded)

def unregister():
    for c in _classes:
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.blosm
    bpy.app.handlers.load_post.remove(_onFileLoaded)
